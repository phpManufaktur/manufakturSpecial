<?php

/**
 * manufakturSpecial
 *
 * @author Ralf Hertsch <ralf.hertsch@phpmanufaktur.de>
 * @link https://phpmanufaktur.de
 * @copyright 2012
 * @license ONLY FOR USE AT PHPMANUFAKTUR.DE - ANY OTHER USE IS FORBIDDEN!
 */

if (!defined('LEPTON_PATH')) define('LEPTON_PATH', WB_PATH);
if (!defined('LEPTON_URL')) define('LEPTON_URL', WB_URL);